# Captions · piezas sociales

Generado desde `brand/content/posts.json`. Todas las cifras son ilustrativas y se verifican con `lib/finance/engine.ts`. No anuncian acceso público ni conexión bancaria.

## 01-banco-baja

**Titular:** Tu banco bajó $500. ¿Tu patrimonio también?

El saldo del banco no cuenta toda la historia. Si este mes salieron $500 del banco pero tu deuda bajó $1,000, tu patrimonio subió $500. Activos menos deudas: siempre las dos columnas. Ejemplo ilustrativo.

#finanzaspersonales #patrimonio #educacionfinanciera

**Alt text:** Tu banco bajó $500. ¿Tu patrimonio también? Banco −$500 (salió dinero), Deuda −$1,000 (debes menos); Patrimonio +$500. Ejemplo ilustrativo.

## 02-dos-destinos

**Titular:** Cada cuota tiene dos destinos.

Una cuota de $302.58 no es un gasto de $302.58. En este ejemplo, $84.74 son interés (gasto) y $217.84 son capital: salen del banco y reducen tu deuda en la misma cantidad. La tasa y el saldo determinan el cálculo real. Ejemplo ilustrativo.

#prestamos #finanzaspersonales #deudas

**Alt text:** Cada cuota tiene dos destinos. Interés $84.74 (es gasto), Capital $217.84 (reduce la deuda); Cuota $302.58. Ejemplo ilustrativo.

## 03-nueva-deuda

**Titular:** Pedir prestado no te hace más rico.

Recibir un préstamo de $5,000 sube tu banco y tu deuda en lo mismo: el patrimonio no cambia. Lo que decide si mejora o empeora es qué haces con ese dinero y cuánto interés pagas. Ejemplo ilustrativo.

#deuda #finanzaspersonales #patrimonio

**Alt text:** Pedir prestado no te hace más rico. Banco +$5,000 (entra el préstamo), Deuda +$5,000 (debes más); Patrimonio $0. Ejemplo ilustrativo.

## 04-pago-extra

**Titular:** $100 más al mes. ¿Cuánto ahorras?

En un préstamo de $15,644 al 6.5% con cuota de $302.58, sumar $100 al mes te ahorra $791.24 en intereses y terminas 17 meses antes. El simulador de Personal CFO hace esta cuenta con tus números. Ejemplo ilustrativo.

#deudas #prestamos #finanzaspersonales

**Alt text:** $100 más al mes. ¿Cuánto ahorras? Pago extra +$100.00 (cada mes, directo a capital), Terminas antes 17 meses (menos cuotas por pagar); Intereses +$791.24. Ejemplo ilustrativo.

## 05-cuota-corta

**Titular:** Pagas cada mes y la deuda no baja.

Si tu cuota es menor que el interés del mes, pagas y la deuda no baja (y a veces sube). Personal CFO te avisa cuando un préstamo no amortiza. Ejemplo ilustrativo.

#tarjetasdecredito #deudas #finanzaspersonales

**Alt text:** Pagas cada mes y la deuda no baja. Interés $150.00 (toda la cuota se va aquí), Capital $0.00 (la deuda sigue igual); Cuota $150.00. Ejemplo ilustrativo.

## 06-negativo

**Titular:** Patrimonio negativo, pero mejorando.

Mucha gente empieza con patrimonio negativo por un préstamo estudiantil. No es un fracaso: es un punto de partida. Si este mes ahorraste $200 y tu deuda bajó $400, tu patrimonio mejoró $600. Ejemplo ilustrativo.

#prestamoestudiantil #finanzaspersonales #patrimonio

**Alt text:** Patrimonio negativo, pero mejorando. Banco +$200 (ahorraste), Deuda −$400 (debes menos); Patrimonio +$600. Ejemplo ilustrativo.

## 07-pack-sesiones

**Titular:** 4 sesiones de 60 min con un profesional.

Revisa tu balance, arma un plan para tus deudas y crea hábitos con uno de nuestros profesionales (Economía, Máster en Finanzas, MBA). Sesión de balance $100 · Plan de deudas $180 · Pack de 4 sesiones $340. Solo educación y coaching de finanzas personales; no recomendamos inversiones específicas. Agenda desde el enlace en la bio.

#finanzaspersonales #educacionfinanciera #coachfinanciero

**Alt text:** 4 sesiones de 60 min con un profesional. 4 sesiones sueltas $400 ($100 cada una), Pack de 4 sesiones $340 ($85 por sesión); Ahorras +$60. Precios en USD · educación financiera, no asesoría de inversión
