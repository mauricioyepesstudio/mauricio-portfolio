# Marca

Fuente completa: `docs/IDENTIDAD-Y-UX.md`. Aquí solo el resumen para consulta rápida.

- **Nombre:** Personal CFO (antes «Patrimonio CFO»). Handle de redes: @personalcfohq. Correo del negocio: personalcfohq@gmail.com (`CONTACT_EMAIL`).
- **Símbolo:** la «P» con trayectoria; logotipo con texto convertido a trazos (4 variantes + mono).
- **Voz:** precisa, tranquila, directa. Explica el hecho, la causa verificable y el dato faltante. Lenguaje no técnico, en español.
- **Paleta:** navy `#102A43` · mint `#72E3B2` · teal `#127C70` · tealDark `#0B5147` · muted `#526B7F` · loss `#A04F4A` · fondo `#F3F6F8`. Nunca solo color: siempre signo y palabra.
- **Tipografía:** Arial/Helvetica (portable).
- **Gráficas:** un eje, meses sin cierre como hueco, paletas aptas para daltonismo.
- **Reglas de contenido:** toda cifra inventada lleva «Ejemplo ilustrativo»; sin diagnósticos de «salud financiera»; no anunciar conexión bancaria ni acceso público; equipo por titulaciones, sin nombres ni fotos; nunca «asesor financiero/de inversiones».
- **Generación:** `npm run brand` (posts desde `brand/content/posts.json`, formatos 1:1, 4:5, 9:16; cifras verificadas con el motor).

## Pendiente de completar

- Revisión legal/registro del nombre «Personal CFO» (término de uso común) y del dominio.
- Guía de tono para respuestas a clientes y para charlas (ejemplos propios de Miguel).
- Estado real de los perfiles de redes (¿creados y publicados?).
