import Reveal from "./Reveal";
import { services } from "@/lib/content";

export default function Services() {
  return (
    <section className="py-28 md:py-40 border-t border-line" id="services">
      <div className="container-px max-w-content mx-auto">
        <Reveal>
          <p className="eyebrow mb-4">What I Do</p>
          <h2 className="font-sans font-semibold text-display-md text-paper mb-16 max-w-2xl">
            Services built around brand growth, not just deliverables.
          </h2>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-line">
          {services.map((service, i) => (
            <Reveal key={service.title} delay={i * 0.05}>
              <div className="bg-ink p-8 h-full group hover:bg-[#111111] transition-colors duration-500">
                <span className="text-xs text-gold font-medium">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg text-paper font-medium mt-4 mb-3">
                  {service.title}
                </h3>
                <p className="text-sm text-bone leading-relaxed">
                  {service.description}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
