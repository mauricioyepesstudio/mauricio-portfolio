"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import type { Project } from "@/lib/projects";

export default function ProjectCard({ project }: { project: Project }) {
  return (
    <Link
      href={`/portfolio/${project.slug}`}
      className="group block"
      aria-label={`View case study: ${project.title}`}
    >
      <motion.article
        whileHover={{ y: -8 }}
        transition={{ duration: 0.35 }}
        className="overflow-hidden rounded-3xl border border-white/10 bg-[#111] shadow-xl"
      >
        {/* IMAGE AREA */}

        <div
          className="relative aspect-[16/10] overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${project.cover.from}, ${project.cover.to})`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />

          <motion.div
            whileHover={{ scale: 1.08 }}
            transition={{ duration: 0.6 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <span className="font-serif text-6xl md:text-7xl italic text-white/12 tracking-tight">
              {project.title}
            </span>
          </motion.div>

          <div className="absolute left-8 bottom-8 z-20">
            <p className="text-xs uppercase tracking-[0.35em] text-gold mb-2">
              {project.category}
            </p>

            <h3 className="text-3xl md:text-4xl font-serif text-white leading-none">
              {project.title}
            </h3>

            <p className="text-white/70 mt-2">
              {project.client}
            </p>
          </div>

          <motion.div
            whileHover={{ rotate: 45 }}
            transition={{ duration: .25 }}
            className="absolute top-6 right-6 h-14 w-14 rounded-full bg-white text-black flex items-center justify-center"
          >
            <ArrowUpRight size={22} />
          </motion.div>
        </div>

        {/* CONTENT */}

        <div className="p-8">
          <p className="text-white/75 leading-7 text-base">
            {project.excerpt}
          </p>

          <div className="mt-8 flex flex-wrap gap-2">
            {project.services.slice(0,3).map((service)=>(
              <span
                key={service}
                className="rounded-full border border-white/10 px-4 py-2 text-xs uppercase tracking-wider text-white/70"
              >
                {service}
              </span>
            ))}
          </div>

          <div className="mt-8 flex items-center justify-between border-t border-white/10 pt-6">
            <span className="text-sm text-white/40">
              {project.year}
            </span>

            <span className="flex items-center gap-2 text-gold font-medium group-hover:gap-4 transition-all">
              View Case Study
              <ArrowUpRight size={16}/>
            </span>
          </div>
        </div>
      </motion.article>
    </Link>
  );
}
