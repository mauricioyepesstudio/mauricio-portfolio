import Reveal from "@/components/Reveal";

type Metric = {
  label: string;
  value: string;
};

type ProjectMetricsProps = {
  metrics: Metric[];
};

export default function ProjectMetrics({
  metrics,
}: ProjectMetricsProps) {
  return (
    <section className="mt-20">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <Reveal key={metric.label} delay={index * 0.08}>
            <div className="rounded-2xl border border-line bg-white/[0.02] p-8 h-full">
              <p className="font-serif italic text-4xl text-gold">
                {metric.value}
              </p>

              <p className="mt-3 text-xs uppercase tracking-[0.18em] text-bone">
                {metric.label}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}