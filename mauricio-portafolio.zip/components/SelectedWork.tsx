import Link from "next/link";
import Reveal from "./Reveal";
import ProjectCard from "./ProjectCard";
import { projects } from "@/lib/projects";

export default function SelectedWork() {
  return (
    <section className="py-28 md:py-40 border-t border-line" id="work">
      <div className="container-px max-w-content mx-auto">
        <div className="flex items-end justify-between flex-wrap gap-6 mb-16">
          <Reveal>
            <div>
              <p className="eyebrow mb-4">Portfolio</p>
              <h2 className="font-sans font-semibold text-display-md text-paper">
                Selected Work
              </h2>
            </div>
          </Reveal>
          <Reveal delay={0.15}>
            <Link
              href="/portfolio"
              className="text-sm text-bone hover:text-paper border-b border-transparent hover:border-paper transition-colors pb-1"
            >
              View all case studies →
            </Link>
          </Reveal>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.slice(0, 4).map((project, i) => (
            <Reveal key={project.slug} delay={i * 0.1}>
              <ProjectCard project={project} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
