import Reveal from "@/components/Reveal";

type ProjectHeroProps = {
  title: string;
  category: string;
  client: string;
  year: string;
  image?: string;
  from: string;
  to: string;
};

export default function ProjectHero({
  title,
  category,
  client,
  year,
  image,
  from,
  to,
}: ProjectHeroProps) {
  return (
    <Reveal delay={0.15}>
      <section className="mt-16">
        <div className="relative overflow-hidden rounded-3xl border border-white/10 aspect-[16/9]">
          {image ? (
            <>
              <img
                src={image}
                alt={title}
                className="absolute inset-0 h-full w-full object-cover"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/35 to-transparent" />
            </>
          ) : (
            <div
              className="absolute inset-0"
              style={{
                background: `linear-gradient(135deg, ${from}, ${to})`,
              }}
            />
          )}

          <div className="absolute left-10 bottom-10 md:left-16 md:bottom-16 max-w-3xl">
            <p className="eyebrow mb-4">{category}</p>

            <h1 className="font-sans font-semibold text-5xl md:text-7xl text-paper leading-none">
              {title}
            </h1>

            <div className="flex flex-wrap gap-6 mt-8 text-sm uppercase tracking-[0.18em] text-bone">
              <span>{client}</span>
              <span>•</span>
              <span>{year}</span>
            </div>
          </div>
        </div>
      </section>
    </Reveal>
  );
}