"use client";

import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";

const words = [
  "Creative Director.",
  "Building brands",
  "people remember.",
];

const container = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.2,
    },
  },
};

const line = {
  hidden: {
    opacity: 0,
    y: 60,
  },
  show: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 1,
      ease: [0.16, 1, 0.3, 1] as const,
    },
  },
};

export default function Hero() {
  return (
    <section className="relative min-h-[100svh] flex flex-col justify-center bg-radial-fade overflow-hidden">
      <div className="container-px max-w-content mx-auto w-full pt-24 pb-16 relative z-10">
  <div className="grid lg:grid-cols-2 items-center gap-20">
  <div>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="eyebrow mb-6"
        >
          Miami, Florida • Available Worldwide
        </motion.p>

        <motion.h1
          variants={container}
          initial="hidden"
          animate="show"
          className="font-sans font-semibold text-display-xl text-paper leading-[0.95]"
        >
          {words.map((word, i) => (
            <motion.span
              key={word}
              variants={line}
              className="block"
            >
              {i === 2 ? (
                <span className="font-serif italic font-normal text-gold">
                  {word}
                </span>
              ) : (
                word
              )}
            </motion.span>
          ))}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.8,
            delay: 0.9,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="mt-8 text-lg md:text-xl text-bone max-w-2xl leading-relaxed"
        >
          I help companies increase sales through branding,
          advertising, editorial design, digital marketing and
          AI-powered creative solutions that connect with people,
          strengthen brands and drive measurable business growth.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.8,
            delay: 1.1,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="mt-12 flex flex-wrap items-center gap-4"
        >
          <Link
            href="/portfolio"
            className="inline-flex items-center justify-center bg-paper text-ink px-8 py-4 rounded-full text-sm font-semibold tracking-wide hover:bg-gold transition-all duration-300"
          >
            View My Work
          </Link>

          <a
            href="/resume.pdf"
            download
            className="inline-flex items-center justify-center border border-line px-8 py-4 rounded-full text-sm font-semibold tracking-wide text-paper hover:border-paper transition-all duration-300"
          >
            Resume
          </a>

          <Link
            href="/contact"
            className="inline-flex items-center justify-center px-8 py-4 rounded-full text-sm font-semibold tracking-wide text-bone hover:text-paper transition-all duration-300"
          >
            Let's Talk →
          </Link>
        </motion.div>

        {/* Statistics */}

        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.8,
            delay: 1.4,
          }}
          className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-10 border-t border-line pt-10"
        >
          <div>
            <h3 className="text-5xl font-semibold text-paper">
              20+
            </h3>
            <p className="mt-3 text-bone text-sm uppercase tracking-wider">
              Years Experience
            </p>
          </div>

          <div>
            <h3 className="text-5xl font-semibold text-paper">
              300+
            </h3>
            <p className="mt-3 text-bone text-sm uppercase tracking-wider">
              Projects Delivered
            </p>
          </div>

          <div>
            <h3 className="text-5xl font-semibold text-paper">
              100+
            </h3>
            <p className="mt-3 text-bone text-sm uppercase tracking-wider">
              Brands Worked With
            </p>
          </div>

          <div>
            <h3 className="text-5xl font-semibold text-paper">
              2
            </h3>
            <p className="mt-3 text-bone text-sm uppercase tracking-wider">
              Languages
            </p>
          </div>
          </motion.div>
      </div>

<div className="relative flex justify-center lg:justify-end">

  <div className="absolute w-[650px] h-[650px] rounded-full bg-gold/10 blur-[120px]" />

  <motion.div
    initial={{ opacity: 0, x: 80, scale: 0.9 }}
    animate={{ opacity: 1, x: 0, scale: 1 }}
    transition={{
      duration: 1.2,
      delay: 0.6,
      ease: [0.16, 1, 0.3, 1],
    }}
    className="relative"
  >
    <Image
      src="/images/mauricio.png"
      alt="Mauricio Yepes"
      width={720}
      height={900}
      priority
      className="relative z-10 w-full max-w-[620px] drop-shadow-[0_40px_90px_rgba(0,0,0,.45)]"
    />
  </motion.div>

</div>

</div>
</div>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{
          duration: 1,
          delay: 1.8,
        }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-bone"
        aria-hidden="true"
      >
        <span className="text-xs tracking-[0.3em] uppercase">
          Scroll
        </span>

        <motion.div
          animate={{
            y: [0, 8, 0],
          }}
          transition={{
            duration: 1.8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <ArrowDown size={18} />
        </motion.div>
      </motion.div>
    </section>
  );
}