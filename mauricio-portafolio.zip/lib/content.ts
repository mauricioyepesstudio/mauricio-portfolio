export const services = [
  {
    title: "Creative Direction",
    description:
      "Leading creative vision from concept to execution across branding, advertising, digital experiences and integrated marketing campaigns.",
  },
  {
    title: "Brand Identity",
    description:
      "Building memorable visual identities, logo systems, typography and brand guidelines that create consistency across every touchpoint.",
  },
  {
    title: "Editorial Design",
    description:
      "Designing magazines, catalogs, brochures and corporate publications with strong visual storytelling and refined typography.",
  },
  {
    title: "Advertising & Campaigns",
    description:
      "Developing integrated campaigns for print, digital and social media focused on brand awareness, engagement and business growth.",
  },
  {
    title: "Digital Marketing",
    description:
      "Creating high-converting creative assets for Meta Ads, Google Ads, email marketing, landing pages and social media.",
  },
  {
    title: "Website Design",
    description:
      "Designing modern, responsive websites that combine aesthetics, usability and conversion-focused user experiences.",
  },
  {
    title: "AI Creative",
    description:
      "Leveraging AI tools to accelerate creative production, concept development, image generation and marketing workflows.",
  },
  {
    title: "Print & Production",
    description:
      "Preparing production-ready artwork for magazines, packaging, large-format printing and commercial offset production.",
  },
];

export const experience = [
  {
    role: "Creative Director & Marketing Strategist",
    org: "Real Group Entertainment LLC",
    location: "Miami, Florida",
    period: "2021 — Present",
    description:
      "Leading branding, creative direction, editorial design, digital marketing, web design and advertising campaigns for businesses across the United States and Latin America.",
  },
  {
    role: "Senior Graphic Designer & Marketing Specialist",
    org: "International Clients",
    location: "United States & Colombia",
    period: "2015 — Present",
    description:
      "Collaborating with international brands to create visual identities, product launches, packaging, editorial publications, advertising campaigns and digital experiences.",
  },
  {
    role: "Graphic Designer & Art Director",
    org: "Advertising Agencies & Consumer Brands",
    location: "Colombia",
    period: "2003 — 2015",
    description:
      "Designed advertising campaigns, magazines, packaging, retail graphics, POP materials and marketing assets for leading consumer brands throughout Colombia.",
  },
];

export const testimonials = [];

export const skills = {
  design: [
    "Creative Direction",
    "Brand Identity",
    "Editorial Design",
    "Advertising Design",
    "Packaging Design",
    "Art Direction",
    "Typography",
    "Visual Storytelling",
  ],

  production: [
    "Print Production",
    "Prepress",
    "Large Format",
    "Magazine Production",
    "Photography Direction",
    "Vendor Management",
  ],

  digital: [
    "Website Design",
    "UI Design",
    "Landing Pages",
    "Digital Marketing",
    "Meta Ads",
    "Google Ads",
    "SEO",
    "Campaign Strategy",
    "Email Marketing",
    "AI Creative",
  ],

  tools: [
    "Adobe Photoshop",
    "Adobe Illustrator",
    "Adobe InDesign",
    "Adobe After Effects",
    "Adobe Premiere Pro",
    "Figma",
    "WordPress",
    "Elementor",
    "Shopify",
    "Canva",
    "Midjourney",
    "ChatGPT",
  ],
};

export const languages = [
  "Spanish — Native",
  "English — Professional Working Proficiency",
];
