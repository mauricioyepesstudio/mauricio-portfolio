export type Project = {
  slug: string;
  title: string;
  client: string;
  category: string;
  year: string;
  cover: {
    from: string;
    to: string;
  };
  excerpt: string;
  services: string[];
  problem: string;
  strategy: string;
  solution: string;
  result: string;
  metrics: { label: string; value: string }[];
};

export const projects: Project[] = [
  {
    slug: "fk-irons",
    title: "FK Irons",
    client: "FK Irons",
    category: "Creative Direction",
    year: "2024",
    cover: { from: "#3b0d0d", to: "#0a0a0a" },
    excerpt:
      "Creative direction and marketing design for one of the world's leading tattoo equipment manufacturers.",
    services: [
      "Creative Direction",
      "Advertising",
      "Digital Marketing",
      "Brand Design",
    ],
    problem:
      "Develop premium creative assets while maintaining a consistent global brand identity.",
    strategy:
      "Create a scalable visual system capable of supporting launches, campaigns and day-to-day marketing.",
    solution:
      "Designed advertising campaigns, digital assets, product promotions and branded communication following strict brand guidelines.",
    result:
      "Delivered a cohesive collection of creative assets that strengthened the visual consistency of the brand.",
    metrics: [
      { label: "Industry", value: "Tattoo" },
      { label: "Market", value: "Global" },
      { label: "Deliverables", value: "50+" },
      { label: "Role", value: "Creative" },
    ],
  },

  {
    slug: "resource-living",
    title: "Resource Living",
    client: "Resource Living Magazine",
    category: "Editorial Design",
    year: "2025",
    cover: { from: "#27415a", to: "#0a0a0a" },
    excerpt:
      "Creative direction, editorial design and marketing for a South Florida home improvement publication.",
    services: [
      "Editorial Design",
      "Creative Direction",
      "Advertising",
      "Digital Marketing",
    ],
    problem:
      "Build a recognizable publication while helping local businesses generate qualified leads.",
    strategy:
      "Combine editorial storytelling with advertising and digital marketing into a single visual ecosystem.",
    solution:
      "Designed the publication, advertisements, landing pages, promotional campaigns and marketing assets.",
    result:
      "Created a consistent publication experience across print and digital channels.",
    metrics: [
      { label: "Industry", value: "Publishing" },
      { label: "Region", value: "Florida" },
      { label: "Media", value: "Print + Digital" },
      { label: "Focus", value: "Lead Generation" },
    ],
  },

  {
    slug: "grupo-nutresa",
    title: "Grupo Nutresa",
    client: "Grupo Nutresa",
    category: "Advertising Design",
    year: "2016",
    cover: { from: "#6a3d10", to: "#0a0a0a" },
    excerpt:
      "Creative work developed for one of Latin America's largest consumer goods companies.",
    services: [
      "Advertising",
      "Packaging",
      "Brand Design",
      "Print Design",
    ],
    problem:
      "Support established consumer brands with consistent and effective visual communication.",
    strategy:
      "Create high-quality graphic solutions aligned with each brand's identity.",
    solution:
      "Designed advertising pieces, packaging support materials and promotional graphics.",
    result:
      "Delivered creative assets across multiple brands within the Nutresa portfolio.",
    metrics: [
      { label: "Industry", value: "Food" },
      { label: "Brands", value: "Multiple" },
      { label: "Market", value: "LATAM" },
      { label: "Media", value: "Print" },
    ],
  },

  {
    slug: "evenflo-colours",
    title: "Evenflo Colours",
    client: "Evenflo Colours",
    category: "Brand Design",
    year: "2018",
    cover: { from: "#36254b", to: "#0a0a0a" },
    excerpt:
      "Brand identity, marketing and creative support for a consumer products company.",
    services: [
      "Brand Identity",
      "Marketing Design",
      "Packaging",
      "Advertising",
    ],
    problem:
      "Develop a consistent visual identity across different communication channels.",
    strategy:
      "Build a flexible creative system adaptable to print and digital media.",
    solution:
      "Created marketing materials, advertising pieces and brand communication assets.",
    result:
      "Established a cohesive visual language supporting the company's marketing efforts.",
    metrics: [
      { label: "Industry", value: "Consumer" },
      { label: "Focus", value: "Branding" },
      { label: "Media", value: "Print + Digital" },
      { label: "Role", value: "Design" },
    ],
  },
];

export function getProject(slug: string): Project | undefined {
  return projects.find((p) => p.slug === slug);
}
