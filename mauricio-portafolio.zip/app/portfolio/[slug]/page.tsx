import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight } from "lucide-react";
import Reveal from "@/components/Reveal";
import { projects, getProject } from "@/lib/projects";

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) return {};
  return {
    title: `${project.title} — Case Study`,
    description: project.excerpt,
  };
}

export default async function CaseStudyPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) notFound();

  const index = projects.findIndex((p) => p.slug === project.slug);
  const next = projects[(index + 1) % projects.length];

  const sections = [
    { label: "Problem", copy: project.problem },
    { label: "Strategy", copy: project.strategy },
    { label: "Solution", copy: project.solution },
    { label: "Result", copy: project.result },
  ];

  return (
    <article className="pt-40 pb-28 md:pb-40">
      <div className="container-px max-w-content mx-auto">
        <Reveal>
          <Link
            href="/portfolio"
            className="inline-flex items-center gap-2 text-sm text-bone hover:text-paper transition-colors mb-12"
          >
            <ArrowLeft size={16} /> All Case Studies
          </Link>
        </Reveal>

        <div className="grid md:grid-cols-12 gap-8 items-end">
          <Reveal className="md:col-span-8">
            <p className="eyebrow mb-4">{project.category}</p>
            <h1 className="font-sans font-semibold text-display-lg text-paper">
              {project.title}
            </h1>
          </Reveal>
          <Reveal delay={0.1} className="md:col-span-4 md:text-right">
            <p className="text-sm text-bone">{project.client}</p>
            <p className="text-sm text-bone">{project.year}</p>
          </Reveal>
        </div>

        <Reveal delay={0.15}>
          <div
            className="mt-16 aspect-[16/9] rounded-2xl flex items-center justify-center"
            style={{
              background: `linear-gradient(135deg, ${project.cover.from}, ${project.cover.to})`,
            }}
          >
            <span className="font-serif italic text-6xl md:text-8xl text-paper/20 select-none">
              {project.title}
            </span>
          </div>
        </Reveal>

        <div className="grid md:grid-cols-3 gap-8 mt-12">
          <Reveal className="md:col-span-1">
            <p className="eyebrow mb-4">Services</p>
            <ul className="space-y-2">
              {project.services.map((s) => (
                <li key={s} className="text-bone text-sm">
                  {s}
                </li>
              ))}
            </ul>
          </Reveal>
          <div className="md:col-span-2 grid grid-cols-3 gap-6">
            {project.metrics.map((m, i) => (
              <Reveal key={m.label} delay={i * 0.08}>
                <p className="font-serif italic text-3xl md:text-4xl text-gold">
                  {m.value}
                </p>
                <p className="text-xs text-bone mt-2 uppercase tracking-widest2">
                  {m.label}
                </p>
              </Reveal>
            ))}
          </div>
        </div>

        <div className="mt-24 space-y-20">
          {sections.map((section, i) => (
            <Reveal key={section.label} delay={i * 0.05}>
              <div className="grid md:grid-cols-12 gap-6 md:gap-12 border-t border-line pt-10">
                <h2 className="md:col-span-3 font-serif italic text-3xl text-paper">
                  {section.label}
                </h2>
                <p className="md:col-span-9 text-bone text-lg leading-relaxed max-w-3xl">
                  {section.copy}
                </p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1}>
          <div className="mt-28 pt-10 border-t border-line flex justify-between items-center">
            <Link
              href="/contact"
              className="text-sm text-bone hover:text-paper transition-colors"
            >
              Have a similar project?
            </Link>
            <Link
              href={`/portfolio/${next.slug}`}
              className="inline-flex items-center gap-2 text-paper hover:text-gold transition-colors"
            >
              Next case study: {next.title} <ArrowRight size={16} />
            </Link>
          </div>
        </Reveal>
      </div>
    </article>
  );
}
