export type ProjectSection = {
  title: string;
  images: string[];
};

export type Project = {
  slug: string;
  title: string;
  client: string;
  category: string;
  year: string;

  heroImage: string;
  heroVideo?: string;

  gallery: string[];

  sections?: ProjectSection[];

  deliverables: string[];

  cover: {
    from: string;
    to: string;
  };

  excerpt: string;

  services: string[];

  problem: string;
  strategy: string;
  solution: string;
  result: string;

  metrics: {
    label: string;
    value: string;
  }[];
};

import resourceLiving from "./resource-living";
import microbeau from "./microbeau";
import getlost from "./getlost";
import evenflo from "./evenflo";

export const projects: Project[] = [
  resourceLiving,
  microbeau,
  getlost,
  evenflo,
];
export const projects: Project[] = [
  resourceLiving,
  microbeau,
];
export function getProject(slug: string) {
  return projects.find((project) => project.slug === slug);
}