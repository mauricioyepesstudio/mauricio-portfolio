import type { Project } from "./index";

const microbeau: Project = {
  slug: "microbeau",

  title: "Microbeau",

  client: "Microbeau International",

  category: "Brand Marketing",

  year: "2024",

  heroImage: "/projects/microbeau/Flourish in your PMU Career_.png",

  gallery: [
    "/projects/microbeau/Flourish in your PMU Career_.png",
    "/projects/microbeau/Flux Mini Anniversary_ Post 1.png",
    "/projects/microbeau/Flux Mini Anniversary_ Post 4.png",
    "/projects/microbeau/Evenflo EU Blonde 2 Brunette Launch  Post 1.png",
    "/projects/microbeau/Evenflo True Lips Unisex Pigments 2.png",
    "/projects/microbeau/MB Distributor Highlight Post  Flux s.png",
    "/projects/microbeau/MB Last Chance GWP Post 1.png",
    "/projects/microbeau/My business is my Baby Banner Mobile.png",
  ],

  deliverables: [
    "Creative Direction",
    "Social Media Campaigns",
    "Digital Advertising",
    "Email Marketing",
    "Product Launches",
    "Brand Design",
  ],

  cover: {
    from: "#111827",
    to: "#6D28D9",
  },

  excerpt:
    "Creative campaigns and product launches developed for one of the world's leading permanent makeup brands.",

  services: [
    "Art Direction",
    "Campaign Design",
    "Digital Marketing",
    "Social Media",
  ],

  problem:
    "Develop premium marketing campaigns capable of communicating innovation while maintaining a luxury beauty brand identity.",

  strategy:
    "Created highly visual campaigns focused on storytelling, product education, distributor engagement, and customer acquisition across digital platforms.",

  solution:
    "Designed launch campaigns, promotional graphics, email assets, banners, product advertisements, and social media content used internationally.",

  result:
    "Helped strengthen brand consistency, increase engagement, and successfully support multiple global product launches across the PMU industry.",

  metrics: [
    {
      label: "Industry",
      value: "Beauty",
    },
    {
      label: "Campaigns",
      value: "100+",
    },
    {
      label: "Markets",
      value: "Worldwide",
    },
    {
      label: "Role",
      value: "Senior Graphic Designer",
    },
  ],
};

export default microbeau;